"""Errores propios del sistema (ADR-003).

Reemplazan el uso de ``except Exception`` genérico. Cada capa lanza o traduce
errores a esta jerarquía, de modo que la presentación pueda decidir qué mostrar
según el *tipo* de problema y no según el texto de la excepción.

Jerarquía:

    ErrorAplicacion
    ├── ErrorValidacion        → datos ingresados incorrectos (culpa del usuario)
    ├── ErrorNoEncontrado      → el registro solicitado no existe
    ├── ErrorReglaNegocio      → la operación viola una regla del negocio
    │   └── ProductoEnUsoError → se intenta borrar un producto que está en pedidos
    └── ErrorPersistencia      → falla al leer/escribir en la base de datos
        └── ErrorConexion      → no se pudo conectar con SQL Server
"""

from __future__ import annotations


class ErrorAplicacion(Exception):
    """Raíz de todos los errores controlados del sistema.

    ``mensaje_usuario`` es un texto amigable, sin detalles técnicos, pensado
    para mostrarse en pantalla. El detalle técnico va al registro (logging).
    """

    mensaje_usuario = "Ocurrió un problema inesperado. Intente de nuevo."

    def __init__(self, mensaje: str | None = None, *, causa: BaseException | None = None):
        super().__init__(mensaje or self.mensaje_usuario)
        self.mensaje = mensaje or self.mensaje_usuario
        self.causa = causa


class ErrorValidacion(ErrorAplicacion):
    """Uno o varios campos no cumplen las reglas.

    ``errores`` es un diccionario ``{campo: mensaje}`` para que la interfaz
    pueda señalar exactamente qué campo está mal.
    """

    mensaje_usuario = "Revise los datos ingresados."

    def __init__(self, errores: dict[str, str]):
        self.errores = dict(errores)
        detalle = "; ".join(f"{campo}: {msg}" for campo, msg in self.errores.items())
        super().__init__(detalle or self.mensaje_usuario)


class ErrorNoEncontrado(ErrorAplicacion):
    mensaje_usuario = "El registro solicitado no existe o ya fue eliminado."


class ErrorReglaNegocio(ErrorAplicacion):
    mensaje_usuario = "La operación no está permitida por las reglas del negocio."


class ProductoEnUsoError(ErrorReglaNegocio):
    mensaje_usuario = (
        "No se puede eliminar el producto porque está incluido en uno o más pedidos."
    )

    def __init__(self, id_producto: int, *, causa: BaseException | None = None):
        self.id_producto = id_producto
        super().__init__(self.mensaje_usuario, causa=causa)


class ErrorPersistencia(ErrorAplicacion):
    mensaje_usuario = "No se pudo completar la operación en la base de datos."


class ErrorConexion(ErrorPersistencia):
    mensaje_usuario = (
        "No hay conexión con la base de datos. Verifique que el servidor esté disponible."
    )
