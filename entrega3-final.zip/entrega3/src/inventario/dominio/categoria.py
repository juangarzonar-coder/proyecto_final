"""Entidad Categoria (solo lectura dentro del módulo Productos)."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Categoria:
    id: int
    nombre: str
