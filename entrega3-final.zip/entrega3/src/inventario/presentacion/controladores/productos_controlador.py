"""Controlador de la pantalla de Productos.

Contiene la lógica que antes estaba en las funciones anidadas ``guardar()``,
``eliminar()``, ``refrescar()`` y ``cargar_en_form()`` de
``interfaces/productos.py``, pero sin depender de CustomTkinter:

  * recibe diccionarios de texto (lo que el usuario escribió),
  * devuelve ``Resultado`` en lugar de abrir ventanas emergentes,
  * guarda el estado de edición (antes ``id_editando = {"val": None}``).

La vista (``vistas/productos_vista.py``) solo conecta widgets con este objeto.
"""

from __future__ import annotations

from dataclasses import asdict
from decimal import Decimal
from typing import Any, Mapping, Sequence

from inventario.comun.registro import obtener_logger
from inventario.dominio.producto import Producto
from inventario.presentacion.controladores.manejo_errores import ejecutar_accion
from inventario.presentacion.controladores.resultado import Resultado
from inventario.servicios.producto_servicio import ProductoServicio

log = obtener_logger("presentacion.productos")

SIN_CATEGORIAS = "Sin categorías"


# Columnas por defecto de la tabla. La vista puede pedir otras (ver COLUMNAS en
# productos_vista.py): así un campo nuevo no obliga a modificar este archivo.
CAMPOS_TABLA = ("id", "nombre", "descripcion", "precio", "stock", "nombre_categoria")
# Campos de Producto que no se editan directamente en el formulario.
NO_EDITABLES = ("id", "id_categoria", "nombre_categoria")


def formatear(valor: Any) -> Any:
    if valor is None:
        return "—"
    if isinstance(valor, Decimal):
        return f"{valor:,.2f}"
    return valor


def fila_tabla(p: Producto, campos: Sequence[str] = CAMPOS_TABLA) -> tuple:
    """Fila para el Treeview con los atributos pedidos, ya formateados."""
    return tuple(formatear(getattr(p, campo)) for campo in campos)


class ProductosControlador:
    def __init__(self, servicio: ProductoServicio) -> None:
        self._servicio = servicio
        self._categorias: dict[str, int] = {}
        self.id_editando: int | None = None

    # ── Estado ───────────────────────────────────────────────────────────────
    @property
    def editando(self) -> bool:
        return self.id_editando is not None

    @property
    def texto_boton_guardar(self) -> str:
        return "Actualizar" if self.editando else "Guardar Producto"

    @property
    def titulo_formulario(self) -> str:
        return f"Editando producto #{self.id_editando}" if self.editando else "Nuevo Producto"

    def cancelar_edicion(self) -> None:
        self.id_editando = None

    # ── Consultas ────────────────────────────────────────────────────────────
    def cargar_categorias(self) -> Resultado:
        def accion() -> Resultado:
            cats = self._servicio.listar_categorias()
            self._categorias = {c.nombre: c.id for c in cats}
            nombres = list(self._categorias) or [SIN_CATEGORIAS]
            return Resultado.ok(datos=nombres)

        resultado = ejecutar_accion("cargar categorías", accion, log)
        if not resultado.exito:
            # La pantalla igual abre, pero indicando que no hay datos disponibles
            # (no se finge una lista vacía como si fuera correcta).
            return Resultado(False, resultado.mensaje, {}, ["(no disponible)"])
        return resultado

    def listar(self, campos: Sequence[str] = CAMPOS_TABLA) -> Resultado:
        return ejecutar_accion(
            "listar productos",
            lambda: Resultado.ok(datos=[fila_tabla(p, campos) for p in self._servicio.listar()]),
            log,
        )

    def iniciar_edicion(self, id_producto: int) -> Resultado:
        def accion() -> Resultado:
            p = self._servicio.obtener(int(id_producto))
            self.id_editando = p.id
            valores = {
                campo: "" if valor is None else str(valor)
                for campo, valor in asdict(p).items()
                if campo not in NO_EDITABLES
            }
            valores["categoria"] = p.nombre_categoria or ""
            return Resultado.ok(datos=valores)

        return ejecutar_accion("cargar producto para edición", accion, log)

    # ── Comandos ─────────────────────────────────────────────────────────────
    def guardar(self, valores: Mapping[str, str]) -> Resultado:
        # Se pasan todos los campos tal cual; solo la categoría se traduce de
        # nombre (lo que ve el usuario) a id (lo que guarda la base de datos).
        datos = {clave: valor for clave, valor in valores.items() if clave != "categoria"}
        datos["id_categoria"] = self._categorias.get(valores.get("categoria", ""))

        def accion() -> Resultado:
            if self.editando:
                self._servicio.actualizar(self.id_editando, datos)
                self.id_editando = None
                return Resultado.ok("Producto actualizado correctamente.")
            self._servicio.crear(datos)
            return Resultado.ok("Producto agregado correctamente.")

        resultado = ejecutar_accion("guardar producto", accion, log)
        if "id_categoria" in resultado.errores:
            # El dominio habla de id_categoria; el formulario muestra "categoria".
            errores = dict(resultado.errores)
            errores["categoria"] = errores.pop("id_categoria")
            return Resultado.fallo(resultado.mensaje, errores)
        return resultado

    def eliminar(self, id_producto: int | None) -> Resultado:
        if id_producto is None:
            return Resultado.fallo("Selecciona un producto de la tabla.")

        def accion() -> Resultado:
            self._servicio.eliminar(int(id_producto))
            if self.id_editando == int(id_producto):
                self.id_editando = None
            return Resultado.ok("Producto eliminado.")

        return ejecutar_accion("eliminar producto", accion, log)
