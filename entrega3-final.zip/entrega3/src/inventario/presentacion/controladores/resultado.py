"""Resultado de una acción de la interfaz.

En vez de abrir ventanas emergentes desde la lógica, el controlador devuelve un
``Resultado`` que la vista decide cómo mostrar. Las pruebas lo verifican
directamente.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class Resultado:
    exito: bool
    mensaje: str = ""
    errores: dict[str, str] = field(default_factory=dict)
    datos: Any = None

    @classmethod
    def ok(cls, mensaje: str = "", datos: Any = None) -> "Resultado":
        return cls(True, mensaje, {}, datos)

    @classmethod
    def fallo(cls, mensaje: str, errores: dict[str, str] | None = None) -> "Resultado":
        return cls(False, mensaje, dict(errores or {}))
