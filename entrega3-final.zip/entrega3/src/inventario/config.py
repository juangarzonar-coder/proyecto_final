"""Configuración del sistema leída de variables de entorno.

Antes la cadena de conexión estaba escrita a mano en ``conexion.py``. Ahora se
puede cambiar sin tocar código (útil para cada integrante del equipo).

Variables soportadas:

    INVENTARIO_REPO       sqlserver (por defecto) | memoria  → modo demo sin BD
    INVENTARIO_DB_DRIVER  ODBC Driver 17 for SQL Server
    INVENTARIO_DB_SERVER  localhost
    INVENTARIO_DB_NAME    EmpresaLimpiezaDB
    INVENTARIO_DB_USER / INVENTARIO_DB_PASSWORD  (si no se dan → Trusted_Connection)
    INVENTARIO_DB_TIMEOUT 5 (segundos para conectar)
"""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class ConfiguracionBD:
    driver: str = "ODBC Driver 17 for SQL Server"
    servidor: str = "localhost"
    base_datos: str = "EmpresaLimpiezaDB"
    usuario: str | None = None
    clave: str | None = None
    timeout: int = 5

    @classmethod
    def desde_entorno(cls) -> "ConfiguracionBD":
        return cls(
            driver=os.getenv("INVENTARIO_DB_DRIVER", cls.driver),
            servidor=os.getenv("INVENTARIO_DB_SERVER", cls.servidor),
            base_datos=os.getenv("INVENTARIO_DB_NAME", cls.base_datos),
            usuario=os.getenv("INVENTARIO_DB_USER") or None,
            clave=os.getenv("INVENTARIO_DB_PASSWORD") or None,
            timeout=int(os.getenv("INVENTARIO_DB_TIMEOUT", cls.timeout)),
        )

    def cadena_conexion(self) -> str:
        partes = [
            f"DRIVER={{{self.driver}}}",
            f"SERVER={self.servidor}",
            f"DATABASE={self.base_datos}",
        ]
        if self.usuario:
            partes += [f"UID={self.usuario}", f"PWD={self.clave or ''}"]
        else:
            partes.append("Trusted_Connection=yes")
        return ";".join(partes) + ";"


def modo_repositorio() -> str:
    return os.getenv("INVENTARIO_REPO", "sqlserver").strip().lower()
