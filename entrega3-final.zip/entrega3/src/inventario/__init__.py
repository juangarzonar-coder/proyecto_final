"""Nueva arquitectura por capas del sistema EmpresaLimpieza (módulo MVP: Productos)."""

import logging

# Sin configurar_registro() (p. ej. en pruebas) los mensajes no se imprimen en consola.
logging.getLogger("inventario").addHandler(logging.NullHandler())
