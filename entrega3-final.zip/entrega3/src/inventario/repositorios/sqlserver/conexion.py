"""Manejo centralizado de la conexión a SQL Server (ADR-002 y ADR-003).

Antes cada función de ``crud/`` repetía ``conectar()`` / ``commit()`` /
``close()`` y, si algo fallaba a mitad de camino, la conexión quedaba abierta.

``GestorConexion.cursor()`` es un *context manager* que:
  * abre la conexión,
  * hace ``commit`` si todo sale bien o ``rollback`` si hay error,
  * cierra siempre cursor y conexión,
  * traduce los errores de pyodbc a errores propios del sistema.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Callable, Iterator

from inventario.comun.errores import (
    ErrorAplicacion,
    ErrorConexion,
    ErrorPersistencia,
    ErrorReglaNegocio,
)
from inventario.comun.registro import obtener_logger
from inventario.config import ConfiguracionBD

log = obtener_logger(__name__)

# SQLSTATE de violación de integridad (FK, UNIQUE, NOT NULL...)
SQLSTATE_INTEGRIDAD = "23000"
# SQLSTATE de errores de conexión (08xxx) y timeout de login (HYT00)
PREFIJOS_CONEXION = ("08", "HYT")


class ErrorIntegridad(ErrorReglaNegocio):
    """Violación de una restricción de la base de datos."""


def _sqlstate(exc: BaseException) -> str:
    args = getattr(exc, "args", ())
    return str(args[0]) if args else ""


def traducir_error_bd(exc: BaseException, operacion: str) -> ErrorAplicacion:
    """Convierte un error de pyodbc en un error del sistema según su SQLSTATE."""
    estado = _sqlstate(exc)
    if estado.startswith(PREFIJOS_CONEXION) or type(exc).__name__ == "InterfaceError":
        return ErrorConexion(f"Fallo de conexión durante '{operacion}' ({estado})", causa=exc)
    if estado == SQLSTATE_INTEGRIDAD or type(exc).__name__ == "IntegrityError":
        return ErrorIntegridad(
            f"Violación de integridad durante '{operacion}' ({estado})", causa=exc
        )
    return ErrorPersistencia(f"Error de base de datos durante '{operacion}' ({estado})", causa=exc)


def _conectar_pyodbc(config: ConfiguracionBD) -> Any:
    import pyodbc  # importación tardía: las pruebas no necesitan pyodbc

    return pyodbc.connect(config.cadena_conexion(), timeout=config.timeout)


class GestorConexion:
    def __init__(
        self,
        config: ConfiguracionBD | None = None,
        conectar: Callable[[ConfiguracionBD], Any] | None = None,
    ) -> None:
        self.config = config or ConfiguracionBD.desde_entorno()
        self._conectar = conectar or _conectar_pyodbc

    @contextmanager
    def cursor(self, operacion: str = "consulta") -> Iterator[Any]:
        try:
            con = self._conectar(self.config)
        except ErrorAplicacion:
            raise
        except Exception as exc:  # frontera con la librería externa
            error = traducir_error_bd(exc, operacion)
            if not isinstance(error, ErrorConexion):
                error = ErrorConexion(f"No se pudo abrir la conexión ({_sqlstate(exc)})", causa=exc)
            log.error("%s | %r", error.mensaje, exc)
            raise error from exc

        cur = con.cursor()
        try:
            yield cur
            con.commit()
        except ErrorAplicacion:
            con.rollback()
            raise
        except Exception as exc:  # frontera con la librería externa
            con.rollback()
            error = traducir_error_bd(exc, operacion)
            log.error("%s | %r", error.mensaje, exc)
            raise error from exc
        finally:
            cur.close()
            con.close()
