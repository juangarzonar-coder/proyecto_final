"""Contratos de acceso a datos (ADR-002).

Los servicios dependen de estas abstracciones, no de SQL Server. Cualquier
clase que tenga estos métodos sirve: el repositorio real (``sqlserver``) o el
repositorio en memoria usado en las pruebas y en el modo demo.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from inventario.dominio.categoria import Categoria
from inventario.dominio.producto import Producto


@runtime_checkable
class ProductoRepositorio(Protocol):
    def listar(self) -> list[Producto]: ...

    def obtener(self, id_producto: int) -> Producto | None: ...

    def agregar(self, producto: Producto) -> Producto:
        """Guarda el producto y lo devuelve con su ``id`` asignado."""
        ...

    def actualizar(self, producto: Producto) -> None: ...

    def eliminar(self, id_producto: int) -> None: ...

    def esta_en_pedidos(self, id_producto: int) -> bool: ...


@runtime_checkable
class CategoriaRepositorio(Protocol):
    def listar(self) -> list[Categoria]: ...

    def existe(self, id_categoria: int) -> bool: ...
