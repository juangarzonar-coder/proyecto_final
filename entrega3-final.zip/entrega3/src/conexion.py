"""Conexión usada por los módulos que aún NO se han migrado (crud/*.py).

La cadena de conexión ya no está escrita a mano: se toma de la misma
configuración que usa la nueva arquitectura (``inventario.config``), así todo
el sistema apunta a la misma base de datos. Se retirará cuando todos los módulos estén migrados.
"""
import pyodbc

from inventario.config import ConfiguracionBD


def conectar():
    config = ConfiguracionBD.desde_entorno()
    return pyodbc.connect(config.cadena_conexion(), timeout=config.timeout)
